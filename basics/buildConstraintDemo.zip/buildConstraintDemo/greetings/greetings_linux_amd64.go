// +build linux,amd64

package greetings

import "fmt"

func Greet(){
	fmt.Println("Hello from linux_amd64")
}

