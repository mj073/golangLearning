// +build windows,amd64

package greetings

import "fmt"

func Greet(){
	fmt.Println("Hello from windows_amd64")
}