package main

import (
	"basics/buildConstraintDemo/greetings"
)

func main(){
	greetings.Greet()
}
