package main

import "basics/buildConstraintDemo/demo/utils"

func main(){
	utils.DoSomething()
}
