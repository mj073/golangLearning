package utils

import "fmt"

func Done(){
	fmt.Println("Done")
}
